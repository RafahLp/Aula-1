package Aula1;
import java.util.ArrayList;

public class Geometria {

	public static void main(String[] args) {
		ArrayList<Figura> figuras = new ArrayList<Figura>();
		
		Circulo circulo = new Circulo(5);
		Triangulo triangulo = new Triangulo(5, 2.4, 3, 4);
		Losango losango = new Losango(4, 5);
		Retangulo retangulo = new Retangulo(3, 4);
		Quadrado quadrado = new Quadrado(7);
		Trapezio trapezio = new Trapezio(4, 10, 4, 5, 5);
		Cubo cubo = new Cubo(5);
		Esfera esfera = new Esfera(2);
		Cilindro cilindro = new Cilindro(2, 5);
		Piramide piramide = new Piramide(5, 5);
		
		figuras.add(circulo);
		figuras.add(triangulo);
		figuras.add(losango);
		figuras.add(retangulo);
		figuras.add(quadrado);
		figuras.add(trapezio);
		figuras.add(cubo);
		figuras.add(esfera);
		figuras.add(cilindro);
		figuras.add(piramide);
		
		for(Figura figura: figuras) {
			System.out.println(figura);
		    if(figura instanceof Diagonal) {
		    	System.out.println("Diagonal = " + ((Diagonal)figura).calculoDiagonal());
		    }
		    if(figura instanceof Volume) {
		    	System.out.println("Volume = " + ((Volume)figura).calculaVolume());
		    }
			System.out.println("�rea = " + figura.area());
		    System.out.println("Perimetro = " + figura.perimetro() + "\n");
		}

	}

}

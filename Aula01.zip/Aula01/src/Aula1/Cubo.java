package Aula1;

public class Cubo extends Quadrado implements Volume, Diagonal{

	private double aresta;
	
	public Cubo(double aresta) {
		super(aresta);
		this.aresta = aresta;
	}
	
	public void setLado(double aresta) {
		this.aresta = aresta;
	}
	public double getAresta() {
		return aresta;
	}
	
	@Override
	public double calculaVolume() {
		return aresta * aresta * aresta;
	}
	
	@Override
	public double calculoDiagonal() {
		return aresta * Math.sqrt(3);
	}
	
	@Override
	public double area() {
		return aresta * aresta * 6;
	}
	
	@Override
	public double perimetro() {
		return aresta * 12;
	}
}

package Aula1;

public class Trapezio extends Poligono {
	
	private double baseMenor, baseMaior, lado1, lado2, altura;

	public Trapezio(double baseMenor, double baseMaior, double altura, double lado1, double lado2) {
		super(baseMenor, altura);
		setBaseMenor(baseMenor);
		setBaseMaior(baseMaior);
		setAltura(altura);
		setLado1(lado1);
		setLado2(lado2);
	}

	public double getBaseMenor() {
		return baseMenor;
	}

	public void setBaseMenor(double baseMenor) {
		this.baseMenor = baseMenor;
	}

	public double getBaseMaior() {
		return baseMaior;
	}

	public void setBaseMaior(double baseMaior) {
		this.baseMaior = baseMaior;
	}

	public double getLado1() {
		return lado1;
	}

	public void setLado1(double lado1) {
		this.lado1 = lado1;
	}

	public double getLado2() {
		return lado2;
	}

	public void setLado2(double lado2) {
		this.lado2 = lado2;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	@Override
	public double area() {
		return ((baseMaior + baseMenor) * altura) / 2;
	}

	@Override
	public double perimetro() {
		return baseMenor + baseMaior + lado1 + lado2;
	}

}

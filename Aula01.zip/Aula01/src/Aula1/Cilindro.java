package Aula1;

public class Cilindro extends Circulo implements Volume{
	
    private double raio, altura;
	
    public Cilindro(double raio, double altura) {
		super(raio);
		this.altura = altura;
	}
    
	public double getRaio() {
		return raio;
	}

	public void setRaio(double raio) {
		this.raio = raio;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}
	public double getAltura() {
		return altura;
	}
	
	@Override
	public double calculaVolume() {
		return Math.PI * Math.pow(raio, 3) * altura;
	}
	
	@Override
	public double area() {
		return Math.pow((Math.PI * raio), 2) + 2 * Math.PI * raio * altura;
	}

}

package Aula1;

public interface Diagonal {
	
	public double calculoDiagonal();
	
}

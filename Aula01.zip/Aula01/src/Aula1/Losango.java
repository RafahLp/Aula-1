package Aula1;

public class Losango extends Poligono {
	
	private double base, altura;

	public Losango(double base, double altura) {
		super(base, altura);
		setBase(base);
		setAltura(altura);
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	@Override
	public double area() {
		return base * altura;
	}

	@Override
	public double perimetro() {
		return base * 4;
	}

}

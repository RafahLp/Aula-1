package Aula1;

public class Esfera extends Circulo implements Volume{
	
	private double raio;
	
	public Esfera(double raio) {
		super(raio);
		setRaio(raio);
	}

	public double getRaio() {
		return raio;
	}

	public void setRaio(double raio) {
		this.raio = raio;
	}

	@Override
	public double calculaVolume() {
		return (4/3) * Math.PI * Math.pow(raio, 3);
	}
	
	@Override
	public double area() {
		return 4 * Math.PI * Math.pow(raio, 2);
	}
	
}

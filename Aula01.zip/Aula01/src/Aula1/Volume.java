package Aula1;

public interface Volume {

	public double calculaVolume();
}

package Aula1;

public class Quadrado extends Poligono implements Diagonal {
	
	private double lado, diagonal;

	public Quadrado(double lado) {
		super(lado, lado);
		setLado(lado);
		setDiagonal(calculoDiagonal());
	}

	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}

	public double getDiagonal() {
		return diagonal;
	}

	public void setDiagonal(double diagonal) {
		this.diagonal = diagonal;
	}
	
	@Override
	public double calculoDiagonal() {
		return lado * Math.sqrt(2);
	}

	@Override
	public double area() {
		return lado * lado;
	}

	@Override
	public double perimetro() {
		return lado * 4;
	}

}

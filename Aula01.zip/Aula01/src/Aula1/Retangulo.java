package Aula1;

public class Retangulo extends Poligono implements Diagonal {

	private double base, altura, diagonal;
	
	public Retangulo(double base, double altura) {
		super(base, altura);
		setBase(base);
		setAltura(altura);
		setDiagonal(calculoDiagonal());
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public double getDiagonal() {
		return diagonal;
	}

	public void setDiagonal(double diagonal) {
		this.diagonal = diagonal;
	}
	
	@Override
	public double calculoDiagonal() {
		return Math.sqrt(Math.pow(base, 2) + Math.pow(altura, 2));
	}

	@Override
	public double area() {
		return base * altura;
	}

	@Override
	public double perimetro() {
		return base + base + altura + altura;
	}

}

package Aula1;

public class Piramide extends Quadrado implements Volume{
	
	private double comprimentoBase, altura;
	
	public Piramide(double comprimentoBase, double altura) {
		super(comprimentoBase);
		setComprimentoBase(comprimentoBase);
		setAltura(altura);
	}

	public double getComprimentoBase() {
		return comprimentoBase;
	}

	public void setComprimentoBase(double comprimentoBase) {
		this.comprimentoBase = comprimentoBase;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	@Override
	public double calculaVolume() {
		return ((comprimentoBase * comprimentoBase * altura)/3);
	}
	
	@Override
	public double area() {
		return 0;
	}
	
	@Override
	public double perimetro() {
		return 0;
	}

}
